
var canvas = document.querySelector("canvas");
var ctx = canvas.getContext("2d");

var  width = canvas.width = window.innerWidth;
var  height = canvas.height = window.innerHeight;
let Balls = [];

function random(min,max){
	var result = Math.floor(Math.random()*(max-min)) + min;
	return result;
}

function randomColor(){
	return "rgb(" +
			random(0,255) + "," + 
			random(0,255) + "," + 
			random(0,255) + ")";
}

function Ball(x,y,velX,velY,color,radius){
	this.x = x;
	this.y = y;
	this.velX = velX;
	this.velY = velY;
	this.color = color;
	this.radius = radius;
}

Ball.prototype.draw = function(){
	ctx.beginPath();
	ctx.arc(this.x,this.y,this.radius,0,2*Math.PI);
	ctx.fillStyle = this.color;
	ctx.fill();
}

Ball.prototype.update = function(){
	if(this.x + this.radius >= width){
		this.velX = -(this.velX);
	}
	if(this.x - this.radius <= 0){
		this.velX = -(this.velX);
	}
	if(this.y + this.radius >= height){
		this.velY = -(this.velY);
	}
	if(this.y - this.radius <= 0){
		this.velY = -(this.velY);
	}
	this.x += this.velX;
	this.y += this.velY;
}
ball.prototype.colorExchange = function(){
	
}

function loop(){
	ctx.fillStyle = 'rgb(255,255,255)';
	ctx.fillRect(0 ,0 ,width ,height);
	
	while(Balls.length <= 25){
		let ball = new Ball(
		random(0,width),
		random(0,height),
		random(-10,10),
		random(-10,10),
		randomColor(),
		random(15,25)
		)
		Balls.push(ball);
	}
	
	for(let i=0;i<Balls.length;i++){
	  let ball = Balls[i]
	  ball.draw()
	  ball.update()
	}
	
	requestAnimationFrame(loop);
}
	
loop()